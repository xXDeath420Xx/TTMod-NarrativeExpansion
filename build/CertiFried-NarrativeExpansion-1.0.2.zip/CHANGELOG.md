# Changelog

All notable changes to NarrativeExpansion will be documented in this file.

## [1.0.0] - 2025-01-05

### Added
- Initial release
- Extended dialogue system framework
- Quest chain support
- Story content expansion hooks
- Integration with TechtonicaFramework narrative system
