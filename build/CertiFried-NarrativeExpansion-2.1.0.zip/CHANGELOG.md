# Changelog

All notable changes to NarrativeExpansion will be documented in this file.

## [2.1.0] - 2026-01-07

### Changed
- Major narrative system improvements
- Updated dependency on TechtonicaFramework 1.2.0
- Better integration with dialogue systems

## [1.0.0] - 2025-01-05

### Added
- Initial release
- Extended dialogue system framework
- Quest chain support
- Story content expansion hooks
- Integration with TechtonicaFramework narrative system
